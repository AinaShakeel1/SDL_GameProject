// humania.hpp
// #ifndef HUMANIA_HPP
// #define HUMANIA_HPP

// #include <SDL.h>
// #include "KillerFish.hpp" 
// #include "harmlessfish.hpp"
// #include <vector>


// class HUMania {
// public:
//     void update();
//     void drawObjects(SDL_Renderer* gRenderer, SDL_Texture* assets);
//     void createObject(int x, int y);

// private:
//     std::vector<KillerFish> killerFishList;
//     std::vector<HarmlessFish>harmlessfislist;
// };

// #endif // HUMANIA_HPP
