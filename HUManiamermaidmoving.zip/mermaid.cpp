// // mermaid.cpp


#include "Mermaid.hpp"
// Mermaid.cpp



Mermaid::Mermaid(int x, int y) : Fish(x, y, 51, 29, 3, 104), frameleft(0) {
    // Set initial pose or any other initialization logic
    srcRect = {3, 104, 51, 28};
    speed = 20; // Adjust the speed as needed
}

Mermaid::~Mermaid() {
    // Cleanup if necessary
}

void Mermaid::handleInput(SDL_Event& e) {
    // Handle input events for movement
    if (e.type == SDL_KEYDOWN) {
        switch (e.key.keysym.sym) {
            case SDLK_UP:
                moverRect.y -= speed;
                break;
            case SDLK_DOWN:
                moverRect.y += speed;
                break;
            case SDLK_LEFT:
                moverRect.x -= speed;
                frameleft=0;

                break;
            case SDLK_RIGHT:
                moverRect.x += speed;
                frameleft=1;
                break;
        }
    }
}

void Mermaid::update() {
    // Update logic for the mermaid (if needed)

    // Update the frame for animation
    //frameleft is deciding which row of sprite sheet to use. have to name it correctly
    // frameleft = (frameleft + 1) % 3; // Assuming 3 animation frames
    frameright=int(((SDL_GetTicks() / 300)%3));
    // Set srcRect based on the current frame and direction
    if (frameleft == 0 ) {
       
        // Facing left
        // srcRect = {114, 58, 53, 29};
        srcRect.x = 2;
    } else if (frameright == 1) {
        // Facing right
        // srcRect = {3, 104, 51, 28};
        srcRect.x = 58;
    } else if (frameright== 2) {
        // srcRect = {58, 57, 53, 27};
        srcRect.x = 114;
    // } else if (frameright== 3 && moverRect.x >= 1000 / 2) {
    //     srcRect = {57, 105, 53, 27};
    // } else if (frameright == 4 && moverRect.x < 1000/ 2) {
    //     srcRect = {2, 56, 51, 28};
    // } else if (frameright == 5 && moverRect.x >= 1000 / 2) {
    //     srcRect = {113, 106, 53, 29};
    }
    std::cout<<"frame right: "<<srcRect.x<<"please \n";

}

// void Mermaid::drawObjects(SDL_Renderer* renderer, SDL_Texture* assets) {
//     // Set srcRect based on the current frame
//     if (moverRect.x < 1000 / 2) {
//         // Mermaid facing left
//         srcRect = { 114, 58, 53, 29 };
//     } else {
//         // Mermaid facing right
//         srcRect = { 3, 104, 51, 28 };
//     }

//     // Draw logic goes here
//     SDL_RenderCopy(renderer, assets, &srcRect, &moverRect);
// }
void Mermaid::drawObjects(SDL_Renderer* renderer, SDL_Texture* assets) {
    // Set srcRect based on the current frame

    if (frameleft == 0) {
        // Mermaid facing left
        srcRect = { 114, 58, 53, 29 };
    } else {
        // Mermaid facing right
        srcRect = { 3, 104, 51, 28 };
    }

    // Draw logic goes here
    SDL_RenderCopy(renderer, assets, &srcRect, &moverRect);
}
void Mermaid::pushToVector() {
    // Push the current object to its own vector
     mermaidList.push_back(*this);
}