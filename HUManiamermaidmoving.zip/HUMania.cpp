// // HUMania.cpp
// #include "HUMania.hpp"


// //#include "KillerFish.hpp"  // Include the KillerFish header

// void HUMania::drawObjects(SDL_Renderer* gRenderer, SDL_Texture* assets) {
//     for (auto& killerFish : killerFishList) {
//         killerFish.draw(gRenderer, assets);
//         //harmlessfislist.draw(gRenderer,assets);
    
//     }
// }

// void HUMania::createObject(int x, int y) {
//     killerFishList.emplace_back(x, y);
//     harmlessfislist.emplace_back(x,y);
// }
// void HUMania::update() {
//     for (auto& killerFish : killerFishList) {
//         killerFish.update();
//         harmlessfislist.update();
//     }
// }